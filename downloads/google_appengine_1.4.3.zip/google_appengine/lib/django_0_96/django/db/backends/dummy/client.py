from django.db.backends.dummy.base import complain

runshell = complain
